# -*- coding: utf-8 -*-
"""
Created on Wed Feb  7 17:11:59 2024

@author: NIER
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import r2_score, mean_squared_error
import torch
import torch.nn as nn
from torch.autograd import Variable 
from sklearn.metrics import mean_absolute_error
import torch.nn.functional as F 
from torch.optim.lr_scheduler import ReduceLROnPlateau
# import seaborn as sns
import datetime as dt
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from scipy.stats import kendalltau
import os

def create_folder_if_not_exists(folder_path):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"폴더가 생성되었습니다: {folder_path}")
    else:
        print(f"폴더가 이미 존재합니다: {folder_path}")
###############################################################################
###############################################################################
point_num = 4 # number of point (지점 개수)
ite_opt = 30 # optuna iteration
num_epochs = 500 # epochs
num_classes = 1 # number of output classes 
seq_length = 1 # input seq_length size
print_epochs = num_epochs/5
print_epochs2 = num_epochs/10
# hidden_size = 12
# 1D CNN Kernal size = 커널 개수
CNNKS = 2   # CNN 커널 2개
CNNKS2 = CNNKS-1
#device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
device = torch.device("cuda:0")
###############################################################################
###############################################################################

file_nm = "./data/input.xlsx"

###############################################################################
ite_num = 100
for j in range(0, ite_num):
    ite_num_out = j
    result_f = f"./result/{ite_num_out}/"
    create_folder_if_not_exists(result_f)
    for i in range(0, point_num):
        sheet_nm = i
        # sheet_nm = 0
        data_df = pd.read_excel(file_nm,sheet_nm, engine='openpyxl')
        data_df.head()
        data_df
        # 입력변수와 출력변수 지정하기
        Indep = data_df.iloc[:,2:]
        # Dep_ori = data_df['Cyano']
        Dep_ori = data_df.iloc[:,1]
        Date = data_df.iloc[:,0]
    
        ###############################################################################
        # Kendalltau 상관관계 분석을 통한 입력변수 선정 (p-value값이 0.005)
        kendal_pval_save = np.ones((Indep.columns.size,1),dtype=float)
        Indep_sel = np.zeros((Indep.index.size,1),dtype='float32')
    
        # Kendal 방법 적용
        for i in range(Indep.columns.size):
          kendal_val = kendalltau(Dep_ori.values.astype(float),Indep.iloc[:,i])
          kendal_pval_save[i] = kendal_val.pvalue
    
          if kendal_val.pvalue < 0.005:
              Indep_sel = np.concatenate((Indep_sel,Indep.iloc[:,[i]]), axis=1)
    
        Indep_sel = Indep_sel[:,1:]
    
        if Indep_sel.shape[1]%2 == 1:
          Indep_sel = Indep_sel[:,:Indep_sel.shape[1]-1]
    
        ###############################################################################
        df = pd.concat([Dep_ori,pd.DataFrame(Indep_sel)], axis=1)
        df.iloc[:,0] = df.iloc[:,0].apply(lambda x: np.log10(x) if x != 0 else 1)
        # df['Cyano'] = df['Cyano'].apply(lambda x: np.log(x) if x != 0 else 1)
        new_columns = ['Data_' + str(col) for col in df.columns]
        df.columns = new_columns
        df = pd.concat([Date,df], axis=1)
        print(df)
        
        ##############################################################################
        train_start = pd.Timestamp(dt.date(2012,1,1))
        train_end = pd.Timestamp(dt.date(2021,12,31))
        train_data = df.loc[(df.iloc[:, 0] >= train_start) & (df.iloc[:, 0] <= train_end)]
        train_data = train_data.drop(columns=['DATE'])
        
        test_start = pd.Timestamp(dt.date(2021,1,1))
        test_end = pd.Timestamp(dt.date(2022,9,20))
        test_data = df.loc[(df.iloc[:, 0] >= test_start) & (df.iloc[:, 0] <= test_end)]
        test_data = test_data.drop(columns=['DATE'])
        
        predict_start = pd.Timestamp(dt.date(2022, 9,21))
        predict_end = pd.Timestamp(dt.date(2023,12,31))
        predict_data = df.loc[(df.iloc[:, 0] >= predict_start) & (df.iloc[:, 0] <= predict_end)]
        predict_data = predict_data.drop(columns=['DATE'])
        
        X = df.drop(columns=['DATE'])
        y = X.iloc[:, 0:num_classes]
        input_size = len(X.columns)   # input number of feature
        
        X_train_data = train_data
        y_train_data = train_data.iloc[:, 0:num_classes]
        
        X_test_data = test_data
        y_test_data = test_data.iloc[:, 0:num_classes]
        
        X_predict_data = predict_data
        y_predict_data = predict_data.iloc[:, 0:num_classes]
        # OBS = y_predict_data[1:].astype(float)
        dataY_plot = y_predict_data
        
        MIN_train = X_train_data.min()
        MAX_train = X_train_data.max()
        ss_train = StandardScaler()
        mm_train = MinMaxScaler()
        
        X_ss_train = ss_train.fit_transform(X_train_data)
        y_mm_train = mm_train.fit_transform(y_train_data)
        
        X_ss_test = ss_train.fit_transform(X_test_data)
        y_mm_test = mm_train.fit_transform(y_test_data)
        
        X_ss_predict = ss_train.fit_transform(X_predict_data)
        y_mm_predict = mm_train.fit_transform(y_predict_data)
        
        def create_sequences(data, seq_length):
            xxs = []
         
            for i in range(0, len(data)-seq_length):
                xx = data[i:(i+seq_length),:]   
                xxs.append(xx)
               
            return np.array(xxs)
        
        def create_sequences2(data, seq_length):
            yys = []
        
            for i in range(len(data)-seq_length):
                yy = data[i+seq_length]
                yys.append(yy)
        
            return np.array(yys)
        
        XX_train = create_sequences(X_ss_train, seq_length)
        yy_train = create_sequences2(y_mm_train, seq_length)
        
        XX_test = create_sequences(X_ss_test, seq_length)
        yy_test = create_sequences2(y_mm_test, seq_length)
        
        XX_predict = create_sequences(X_ss_predict, seq_length)
        yy_predict = create_sequences2(y_mm_predict, seq_length)
        
        # 가중치를 부여할 변수의 위치
        weighted_idx = 1
        
        # 가중치 배수
        multiples = 1
        
        # 가중치 행렬 생성
        V_weights = torch.ones(XX_train.shape)
        V_weights2 = torch.ones(XX_test.shape)
        V_weights3 = torch.ones(XX_predict.shape)
        V_weights[:, :, weighted_idx] *= multiples  
        V_weights2[:, :, weighted_idx] *= multiples  
        V_weights3[:, :, weighted_idx] *= multiples  
        
        # 가중치 행렬을 입력 데이터에 곱하여 가중치를 적용
        XX_train2 = torch.Tensor(XX_train) * V_weights
        XX_test2 = torch.Tensor(XX_test) * V_weights2
        XX_predict2 = torch.Tensor(XX_predict) * V_weights3
        
        # 텐서를 Variable로 변환
        X_train_tensors = Variable(XX_train2)
        X_test_tensors = Variable(XX_test2)
        X_predict_tensors = Variable(XX_predict2)
        
        y_train_tensors = Variable(torch.Tensor(yy_train))
        y_test_tensors = Variable(torch.Tensor(yy_test))
        y_predict_tensors = Variable(torch.Tensor(yy_predict))
        
        ############################################################################################################################
        ##################################------------------ CNN-GRU 네트워크 --------------------###############################
        ############################################################################################################################
        class LSTM1(nn.Module):
          def __init__(self, num_classes, input_size, hidden_size, num_layers, seq_length, dropout_rate):
            super(LSTM1, self).__init__()
            self.num_classes = num_classes #number of classes
            self.num_layers = num_layers #number of layers
            self.input_size = input_size #input size
            self.hidden_size = hidden_size #hidden state
            self.seq_length = seq_length #sequence length
            self.dropout_rate = dropout_rate
            
            self.conv1 = nn.Conv1d(in_channels=seq_length, out_channels=seq_length, kernel_size = CNNKS, stride = 1) # 1D CNN 레이어 추가    
            # GRU layer
            self.gru = nn.GRU(input_size=input_size, hidden_size=self.hidden_size,
                                      num_layers=self.num_layers, batch_first=True, dropout=self.dropout_rate)
                
            self.fc_1 =  nn.Linear(hidden_size, 128) #fully connected 1
            self.fc = nn.Linear(128, num_classes) #fully connected last layer
            # Define the dropout layer
            self.dropout = nn.Dropout(p=dropout_rate)          
            self.relu = nn.ReLU()           
            
            # Bahdanau Attention layer
            self.attention = BahdanauAttention(hidden_size)
                       
          def reset_hidden_state(self): 
            self.hidden = (
                    torch.zeros(self.num_layers, self.seq_length-1, self.hidden_size),
                    torch.zeros(self.num_layers, self.seq_length-1, self.hidden_size))
    
          def forward(self,x):
            h_0 = Variable(torch.zeros(self.num_layers, x.size(0), self.hidden_size)).to(device) #hidden state
            # c_0 = Variable(torch.zeros(self.num_layers, x.size(0), self.hidden_size)).to(device) #internal state     
            
            # Convolution input through CNN
            # x = self.conv1(x.view(len(x), self.seq_length, self.input_size).to(device))
            # xx = self.input_size-CNNKS2
                       
            # Propagate input through LSTM
            # output, (hn, cn) = self.lstm(x.view(len(x), self.seq_length, xx), (h_0, c_0)) 
            output, hn = self.gru(x.to(device), h_0) #gru with input, hidden, and internal state      
            # output, (hn, cn) = self.lstm(x.to(device), (h_0, c_0)) #lstm with input, hidden, and internal state
            
            # Apply attention
            # output, attention_weights = self.attention(output)   
            
            hn = output.view(-1, self.hidden_size)
            
            out = self.relu(hn)
            out = self.fc_1(out) #first Dense
            out = self.relu(out) #relu
            out = self.fc(out) #Final Output
                      
            return out 
    
        class BahdanauAttention(nn.Module):
            def __init__(self, hidden_size):
                super(BahdanauAttention, self).__init__()
        
                # Linear layer to calculate attention score
                self.attention = nn.Linear(hidden_size, hidden_size)
        
                # Linear layer to calculate attention weights
                self.weight = nn.Linear(hidden_size, 1, bias=False)
                
                # List to store attention weights
                self.attention_weights_list = []
        
            def append_attention_weights(self, attention_weights):
                # Save attention weights
                BahdanauAttention.attention_weights_list.append(attention_weights.detach().cpu().numpy())
                
            def forward(self, encoder_outputs):
                # Encoder outputs shape: batch_size x seq_len x hidden_size
        
                # Calculate attention scores
                attention_scores = self.attention(encoder_outputs)
        
                # Calculate attention weights
                attention_weights = F.softmax(self.weight(attention_scores), dim=1)
        
                # Calculate attention output
                attention_output = torch.bmm(attention_weights.transpose(1, 2), encoder_outputs)
        
                # Return attention output and attention weights
                return attention_output, attention_weights.squeeze()
            
        ############################################################################################################################
        ##################################---------------------Loss Function---------------------###################################
        ############################################################################################################################    
        class MSLELoss(torch.nn.Module):
            def __init__(self, epsilon=1e-5):
                super(MSLELoss, self).__init__()
                self.epsilon = epsilon
        
            def forward(self, y_hat, y):
                return torch.mean((torch.log(1 + y + self.epsilon) - torch.log(1 + y_hat + self.epsilon))**2)
            
            
        class SmapeLoss(torch.nn.Module):
            def __init__(self):
                super(SmapeLoss, self).__init__()
    
            def forward(self, preds, target):
                assert preds.shape == target.shape
                loss = torch.mean(torch.abs(target - preds) / (torch.abs(target) + torch.abs(preds) + 1e-12)) * 200
                return loss
            
        class HuberLoss(torch.nn.Module):
            def __init__(self, delta=1.0):
                super(HuberLoss, self).__init__()
                self.delta = delta
    
            def forward(self, y_hat, y):
                diff = torch.abs(y_hat - y)
                mask = diff < self.delta
                squared_loss = 0.5 * diff**2
                linear_loss = self.delta * (diff - 0.5 * self.delta)
                loss = torch.where(mask, squared_loss, linear_loss)
                return torch.mean(loss)  
            
        class PowerLoss(torch.nn.Module):
            def __init__(self, power):
                super(PowerLoss, self).__init__()
                self.power = power
    
            def forward(self, preds, target):
                assert preds.shape == target.shape, f"Shape of predictions {preds.shape} and targets {target.shape} don't match"
                diff = torch.abs(preds - target)
                loss = torch.mean(torch.pow(diff, self.power))
                return loss    
            
        ###############################################################################################################################
        ### -------------- Loss function selection (1: MSLE, 2: SmoothL1Loss, 3: MSELoss, 4: L1Loss(MAE) ) -------------------------###
        ###                                         5: SmapeLoss, 6: huber_loss, 7: PowerLoss                                       ###
        ###############################################################################################################################
        for i in range(3, 4):
            
            check = i
            
            ###############################################################################################################################
            ###############################-------------------Hyper parameter tuning----------------------#################################
            ###############################################################################################################################
            import optuna
            
            # Define the objective function for Optuna to minimize
            def objective(trial):
                # Define the hyperparameters to optimize
                
                # max_hidden_size = 60
                # max_num_heads = 8
            
                # while True:
                
                    # for i in range(min(max_num_heads, hidden_size // 12), 0, -1):
                    #     if hidden_size % i == 0:
                    #         num_heads2 = i
                    #         break
                    #     else:
                    #         continue
                    # break
            
                # num_heads = int(trial.suggest_int('num_heads', num_heads2, num_heads2))     
                num_layers = trial.suggest_categorical('num_layers', [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
                hidden_size = int(trial.suggest_int('hidden_size', 12, 60))
                dropout_rate = trial.suggest_categorical('dropout_rate', [0.0, 0.1, 0.2, 0.3, 0.4, 0.5])
                learning_rate = trial.suggest_float('learning_rate', 1e-5, 1e-1, log=True)
                max_norm = trial.suggest_float('max_norm', 1.0, 5.0)
                batch_size = trial.suggest_int('batch_size', 1.0, 4.0)
                
                # Initialize the model
                lstm1 = LSTM1(num_classes, input_size, hidden_size, num_layers, seq_length, dropout_rate).to(device)    
                attention = BahdanauAttention(hidden_size).to(device)
                # optimizer = torch.optim.SGD(list(lstm1.parameters()) + list(attention.parameters()), lr=learning_rate)
                optimizer = torch.optim.Adam(list(lstm1.parameters()) + list(attention.parameters()), lr=learning_rate)
                scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.95, patience=print_epochs2, verbose=False, threshold=0.0001, threshold_mode='rel', cooldown=0, min_lr=0, eps=1e-08)
                
                print(f"trial.params: {trial.params}")
                  
                if check == 1:
                    msle_loss = MSLELoss()        
                elif check == 2:        
                    criterion = torch.nn.SmoothL1Loss()
                elif check == 3:    
                    criterion = torch.nn.MSELoss()
                elif check == 4:
                    criterion = torch.nn.L1Loss()  
                elif check == 5:   
                   Smape_loss = SmapeLoss()   
                elif check == 6:    
                   huber_loss = HuberLoss()   
                elif check == 7:   
                   PowerLoss_loss = PowerLoss(power=1.5) 
                elif check == 8 :
                    
                       penalty_factor = 1.5
                       pava = 1.5
                       def weighted_smooth_l1_loss(predictions, targets, weights, penalty_factor):                                 
                            loss_function = PowerLoss(power=pava)
                            diff = loss_function(predictions, targets)
                            penalty = torch.where((predictions < targets), penalty_factor * diff, torch.zeros_like(diff))
                            weighted_loss = torch.mean(weights * (diff + penalty))
                            return weighted_loss
                               
                # Train the model
                if check == 1 or check == 2 or check == 3 or check == 4 or check == 5 \
                    or check == 6 or check == 7 :
                        
                    for epoch in range(num_epochs):
                        lstm1.train()
                        optimizer.zero_grad()
                
                        outputs = lstm1(X_train_tensors)
                        if check == 1:
                            loss = msle_loss(outputs, y_train_tensors.to(device))
                        elif check == 2 or check == 3 or check == 4 :
                            loss = criterion(outputs, y_train_tensors.to(device)) 
                        elif check == 5:    
                            loss = Smape_loss(outputs, y_train_tensors.to(device))    
                        elif check == 6:    
                            loss = huber_loss(outputs, y_train_tensors.to(device))
                        elif check == 7:    
                            loss = PowerLoss_loss(outputs, y_train_tensors.to(device))                            
                            
                        loss.backward()                    
                        torch.nn.utils.clip_grad_norm_(lstm1.parameters(), max_norm=max_norm)
                        optimizer.step()
                        
                        lstm1.eval()
                        with torch.no_grad():
                            outputs = lstm1(X_test_tensors)
                            if check == 1:
                                val_loss = msle_loss(outputs, y_test_tensors.to(device))
                            elif check == 2 or check == 3 or check == 4 :
                                val_loss = criterion(outputs, y_test_tensors.to(device))
                            elif check == 5:    
                                val_loss = Smape_loss(outputs, y_test_tensors.to(device))     
                            elif check == 6:    
                                val_loss = huber_loss(outputs, y_test_tensors.to(device))
                            elif check == 7:     
                                val_loss = PowerLoss_loss(outputs, y_test_tensors.to(device)) 
                                 
                        trial.report(val_loss.item(), epoch)
                        scheduler.step(val_loss)  # Adjust learning rate based on validation loss
                                    
                        if epoch % print_epochs == 0:
                            print('| Epoch [{}/{}  |  {:.1%}  |  Loss: {:.4f}  |  Val Loss: {:.4f}  |  lr: {:.6f} '.format(epoch, num_epochs, epoch/num_epochs, loss.item(), val_loss.item(), optimizer.param_groups[0]['lr']))
                        
                        if epoch == num_epochs - 1:
                            torch.save(lstm1.state_dict(), result_f+"model.pth")
                
                        if trial.should_prune():
                            raise optuna.exceptions.TrialPruned()    
                       
                    return val_loss.item()
                            
                elif check == 8 :   
                    for epoch in range(num_epochs):
                        lstm1.train()
                        optimizer.zero_grad()
                    
                        outputs = lstm1(X_train_tensors)
                        # Define the weights for the weighted loss function
                        weights = torch.abs(y_train_tensors.to(device) - outputs)
                        # Add penalty to weights for underestimation
                        # penalty = torch.where(outputs < y_train_tensors.to(device), penalty_factor * torch.ones_like(weights), torch.ones_like(weights))
                        # weights = weights * penalty
                        loss = weighted_smooth_l1_loss(outputs, y_train_tensors.to(device), weights.to(device), penalty_factor) # penalty_factor 값을 전달
                    
                        loss.backward()
                        torch.nn.utils.clip_grad_norm_(lstm1.parameters(), max_norm=max_norm)
                        optimizer.step()
                    
                        lstm1.eval()
                        with torch.no_grad():
                            outputs = lstm1(X_test_tensors) 
                            # Define the weights for the weighted loss function
                            weights = torch.abs(y_test_tensors.to(device) - outputs)
                            # Add penalty to weights for underestimation
                            # penalty = torch.where(outputs < y_test_tensors.to(device), penalty_factor * torch.ones_like(weights), torch.ones_like(weights))
                            # weights = weights * penalty
                            val_loss = weighted_smooth_l1_loss(outputs, y_test_tensors.to(device), weights.to(device), penalty_factor) # penalty_factor 값을 전달
                    
                        trial.report(val_loss.item(), epoch)
                        scheduler.step(val_loss)  # Adjust learning rate based on validation loss
                                    
                        if epoch % print_epochs == 0:
                            print('| Epoch [{}/{}  |  {:.1%}  |  Loss: {:.4f}  |  Val Loss: {:.4f}  |  lr: {:.6f} '.format(epoch, num_epochs, epoch/num_epochs, loss.item(), val_loss.item(), optimizer.param_groups[0]['lr']))
                    
                        if epoch == num_epochs - 1:
                            torch.save(lstm1.state_dict(), result_f+"model.pth")
                    
                        if trial.should_prune():
                            raise optuna.exceptions.TrialPruned()
                        
                    return val_loss.item()                      
                
            def save_model(study, trial):
                if study.best_trial == trial:
                    # Load the best model            
                    lstm1 = LSTM1(num_classes, input_size, int(trial.params['hidden_size']), trial.params['num_layers'], seq_length, trial.params['dropout_rate']).to(device)
                    
                    attention = BahdanauAttention(int(trial.params['hidden_size'])).to(device)
                    lstm1.load_state_dict(torch.load(result_f+"model.pth"))
                    lstm1.eval()
                    attention.eval()
            
                    # Save the best model's parameters
                    torch.save(lstm1.state_dict(), result_f+f"ite_model_final(p_{sheet_nm}_{check}).pth")        
                    
            study = optuna.create_study(direction='minimize')
            study.optimize(objective, n_trials=ite_opt, callbacks=[save_model])
            print(f"Optimized parameters: {study.best_params}")
            
            # study 객체에서 best_params 추출
            best_params = study.best_params
            
            # 추출한 best_params를 DataFrame으로 변환
            best_df = pd.DataFrame.from_dict(best_params, orient='index', columns=['value'])
            
            # csv 파일로 저장
            best_df.to_csv(result_f+f'ite_best_params_(p_{sheet_nm}_{check}).csv', index=True)  
         
        #############################################################################################################################    
        ######################################----------------Prediction---------------------------##################################   
        #############################################################################################################################
            
            # hyper parameter 불러오기
            best_df = pd.read_csv(result_f+f'./ite_best_params_(p_{sheet_nm}_{check}).csv')
            
            print('Optimized parameters : num_layers {:.1f}'.format(best_df.iloc[0, 1]))
            print('Optimized parameters : hidden_size {:.1f}'.format(best_df.iloc[1, 1]))
            print('Optimized parameters : dropout_rate {:.1f}'.format(best_df.iloc[2, 1]))
            print('Optimized parameters : learning_rate {:.1f}'.format(best_df.iloc[3, 1]))
            print('Optimized parameters : max_norm {:.8f}'.format(best_df.iloc[4, 1]))
            print('Optimized parameters : batch_size {:.8f}'.format(best_df.iloc[5, 1]))    
            
            lstm1 = LSTM1(num_classes, input_size, int(best_df.iloc[1, 1]), int(best_df.iloc[0, 1]), seq_length, int(best_df.iloc[2, 1])).to(device)    
            # lstm1 = LSTM1(num_classes, input_size, hidden_size, num_layers, seq_length, dropout_rate).to(device)    
            # 모델 매개변수 불러오기
            PATH = result_f+f"ite_model_final(p_{sheet_nm}_{check}).pth"
            lstm1.load_state_dict(torch.load(PATH), strict=False)
            lstm1.eval()
                    
            train_predict = lstm1(X_predict_tensors.to(device))#forward pass
            data_predict = train_predict.data.detach().cpu().numpy() #numpy conversion
            dataY_plot = y_predict_tensors.data.numpy()
             
            data_predict = mm_train.inverse_transform(data_predict) #reverse transformation
            dataY_plot = mm_train.inverse_transform(dataY_plot)
            
            # R2, MAE, RMSE
            V_R2 = np.round(r2_score(dataY_plot[:,0], data_predict[:,0]),2)
            V_MAE = np.round(mean_absolute_error(dataY_plot[:,0], data_predict[:,0]),1)
            V_RMSE = np.round(np.sqrt(mean_squared_error(dataY_plot[:,0], data_predict[:,0])),1)
            
            print("Test R2:", V_R2)
            print("MAE_T:", V_MAE)
            print("RMSE_T:", V_RMSE)
            
            ###########################################################################
            ############################### Graph #####################################
            ###########################################################################
            for i in range(0, num_classes):
                plt.figure(figsize=(15,6)) #plotting
                #plt.axvline(x=datanum, c='r', linestyle='--') #size of the training set
                
                plt.plot(dataY_plot[:,i], label='Actuall Data') #actual plot
                plt.plot(data_predict[:,i], label='Predicted Data') #predicted plot
                plt.title(f'{ite_num_out}ite_(point {sheet_nm})  (loss check  {check})   R2  {V_R2}')
                plt.legend()
                plt.show()   
                
            ###########################################################################
            ############################### Result Save ###############################
            ###########################################################################
                
            # Prediction data를 DataFrame으로 변환
            data_predict_df = pd.DataFrame(data_predict)
            
            # csv 파일로 저장
            data_predict_df.to_csv(result_f+f'{ite_num_out}ite_data_predict_(point_{sheet_nm}_{check}).csv', index=False)





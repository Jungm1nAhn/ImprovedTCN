# -*- coding: utf-8 -*-
"""
Created on Wed Feb  7 17:11:59 2024

@author: NIER
"""

import torch
import torch.nn as nn
from torch.nn.utils import weight_norm
from torch.utils.data import TensorDataset, DataLoader
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import torch.optim as optim
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import json
import random
import optuna
import pickle
from sklearn.preprocessing import StandardScaler, MinMaxScaler
from torch.optim.lr_scheduler import ReduceLROnPlateau

import torch.nn as nn
from torch.nn.utils import weight_norm
from scipy.stats import kendalltau

class Chomp1d(nn.Module):
    def __init__(self, chomp_size):
        super(Chomp1d, self).__init__()
        self.chomp_size = chomp_size

    def forward(self, x):
        return x[:, :, :-self.chomp_size].contiguous()


class TemporalBlock(nn.Module):
    def __init__(self, n_inputs, n_outputs, kernel_size, stride, dilation, padding, dropout=0.2):
        super(TemporalBlock, self).__init__()
        self.conv1 = weight_norm(nn.Conv1d(n_inputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation))
        self.chomp1 = Chomp1d(padding)
        self.relu1 = nn.ReLU()
        self.dropout1 = nn.Dropout(dropout)

        self.conv2 = weight_norm(nn.Conv1d(n_outputs, n_outputs, kernel_size,
                                           stride=stride, padding=padding, dilation=dilation))
        self.chomp2 = Chomp1d(padding)
        self.relu2 = nn.ReLU()
        self.dropout2 = nn.Dropout(dropout)

        self.net = nn.Sequential(self.conv1, self.chomp1, self.relu1, self.dropout1,
                                 self.conv2, self.chomp2, self.relu2, self.dropout2)
        self.downsample = nn.Conv1d(n_inputs, n_outputs, 1) if n_inputs != n_outputs else None
        self.relu = nn.ReLU()
        self.init_weights()

    def init_weights(self):
        self.conv1.weight.data.normal_(0, 0.01)
        self.conv2.weight.data.normal_(0, 0.01)
        if self.downsample is not None:
            self.downsample.weight.data.normal_(0, 0.01)

    def forward(self, x):
        out = self.net(x)
        res = x if self.downsample is None else self.downsample(x)
        return self.relu(out + res)


class TemporalConvNet(nn.Module):
    def __init__(self, num_inputs, num_channels, kernel_size=2, dropout=0.2):
        super(TemporalConvNet, self).__init__()
        layers = []
        num_levels = len(num_channels)
        for i in range(num_levels):
            dilation_size = 2 ** i
            in_channels = num_inputs if i == 0 else num_channels[i-1]
            out_channels = num_channels[i]
            layers += [TemporalBlock(in_channels, out_channels, kernel_size, stride=1, dilation=dilation_size,
                                     padding=(kernel_size-1) * dilation_size, dropout=dropout)]

        self.network = nn.Sequential(*layers)

    def forward(self, x):
        return self.network(x)


class TCN(nn.Module):
    def __init__(self, input_size, output_size, num_channels, kernel_size, dropout):
        super(TCN, self).__init__()
        self.tcn = TemporalConvNet(input_size, num_channels, kernel_size, dropout=dropout)
        self.linear1 = nn.Linear(num_channels[-1], output_size)

    def forward(self, x):
        out1 = self.tcn(x)
        out = self.linear1(out1[:, :, -1])
        return out
    
    
def create_tcn_sequences(data, in_seq, out_seq=0):
    xxs = []
    
    for i in range(len(data) - in_seq - out_seq + 1):
        xx = data[i : i + in_seq, :]
        xxs.append(xx)
        
    return np.array(xxs)

def create_tcn_sequences2(data, in_seq, out_seq):
    yys = []
    
    for i in range(len(data) - in_seq - out_seq + 1):
        yy = data[i + in_seq: i + in_seq + out_seq, 0]
        yys.append(yy)
    
    return np.array(yys)

import os
def create_folder_if_not_exists(folder_path):
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)
        print(f"폴더가 생성되었습니다: {folder_path}")
    else:
        print(f"폴더가 이미 존재합니다: {folder_path}")

# 경로/파일이름 설정
dir_script = 'result/tcn/'
file_name = './data/input.xlsx'


Input_Sequence = 1
Output_Sequence = 1
batch_size = 16
scaling = True
train_ratio = 0.8
valid_ratio = 0.1
EPOCHS = 500
print_epochs = EPOCHS / 5
print_epochs2 = EPOCHS/10
TRIALS = 30
point_num = 4 # number of point (지점 개수)

# 장치 설정
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


ite_num = 100
for j in range(0, ite_num):
    ite_num_out = j
    result_f = f"./result/{ite_num_out}/"
    create_folder_if_not_exists(result_f)
    
    for i in range(3, point_num):
        sheet_nm = i
        # 데이터 불러오기
        data_df = pd.read_excel(file_name,sheet_nm, engine='openpyxl')
        
        ###############################################################################
        data_df.head()
        data_df
        # 입력변수와 출력변수 지정하기
        Indep = data_df.iloc[:,2:]
        # Dep_ori = data_df['Cyano']
        Dep_ori = data_df.iloc[:,1]
        Date = data_df.iloc[:,0]
        ###############################################################################
        # Kendalltau 상관관계 분석을 통한 입력변수 선정 (p-value값이 0.005)
        kendal_pval_save = np.ones((Indep.columns.size,1),dtype=float)
        Indep_sel = np.zeros((Indep.index.size,1),dtype='float32')
        
        # Kendal 방법 적용
        for i in range(Indep.columns.size):
          kendal_val = kendalltau(Dep_ori.values.astype(float),Indep.iloc[:,i])
          kendal_pval_save[i] = kendal_val.pvalue
        
          if kendal_val.pvalue < 0.005:
              Indep_sel = np.concatenate((Indep_sel,Indep.iloc[:,[i]]), axis=1)
        
        Indep_sel = Indep_sel[:,1:]
        
        if Indep_sel.shape[1]%2 == 1:
          Indep_sel = Indep_sel[:,:Indep_sel.shape[1]-1]
        
        ###############################################################################
        df = pd.concat([Dep_ori,pd.DataFrame(Indep_sel)], axis=1)
        df.iloc[:,0] = df.iloc[:,0].apply(lambda x: np.log10(x) if x != 0 else 1)
        # df['Cyano'] = df['Cyano'].apply(lambda x: np.log(x) if x != 0 else 1)
        new_columns = ['Data_' + str(col) for col in df.columns]
        df.columns = new_columns
        df = pd.concat([Date,df], axis=1)
        print(df)
        
        
        # 입력 변수 목록을 DataFrame의 열 제목으로 설정합니다.
        # df = df.drop(['id'], axis=1)
        # df.set_index('DATE', inplace=True)
        df = df.drop(['DATE'], axis=1)
        Input_Variables = list(df.columns[:])
        
        # 출력 변수의 열 번호를 설정합니다. 두 번째 열의 제목을 사용합니다.
        Output_Variables = [df.columns[0]]
        
        # 출력 변수의 열 번호를 설정합니다.
        #Output_Variables = [df.columns.get_loc(Output_Variables_name)]
        
        # 출력 변수를 입력 변수 리스트에서 제거합니다.
        #Input_Variables.remove(Output_Variables_name)
        
        # 데이터 전처리
        X = df[Input_Variables]
        y = df[Output_Variables].loc[X.index]
        
        data_len = X.shape[0]
        # data_dates = y.index
        
        X = X.to_numpy()
        y = y.to_numpy()
        
        # 데이터 분할
        train_number = round(data_len*train_ratio)
        valid_number = round(data_len*valid_ratio) + train_number
        
        X_train, y_train = X[:train_number], y[:train_number]
        X_valid, y_valid = X[train_number:valid_number], y[train_number:valid_number]
        X_test, y_test = X[valid_number:], y[valid_number:]
        # test_dates = data_dates[Input_Sequence + valid_number:].astype(str)
        
        # Scaling
        if scaling == True:
            ss_train = StandardScaler()
            mm_train = MinMaxScaler()
            
            X_train = ss_train.fit_transform(X_train)
            y_train = mm_train.fit_transform(y_train)
            
            X_valid = ss_train.transform(X_valid)
            y_valid = mm_train.transform(y_valid)
            
            X_test = ss_train.transform(X_test)
            y_test = mm_train.transform(y_test)
            
        # dataset 생성
        XX_train = create_tcn_sequences(X_train, Input_Sequence, Output_Sequence)
        yy_train = create_tcn_sequences2(y_train, Input_Sequence, Output_Sequence)
        
        XX_valid = create_tcn_sequences(X_valid, Input_Sequence, Output_Sequence)
        yy_valid = create_tcn_sequences2(y_valid, Input_Sequence, Output_Sequence)
        
        XX_test = create_tcn_sequences(X_test, Input_Sequence, Output_Sequence)
        yy_test = create_tcn_sequences2(y_test, Input_Sequence, Output_Sequence)
        
        XX_train = torch.Tensor(XX_train).to(device)
        yy_train = torch.Tensor(yy_train).to(device)
        XX_valid = torch.Tensor(XX_valid).to(device)
        yy_valid = torch.Tensor(yy_valid).to(device)
        XX_test = torch.Tensor(XX_test).to(device)
        yy_test = torch.Tensor(yy_test).to(device)
        
        train_dataset = TensorDataset(XX_train, yy_train)
        valid_dataset = TensorDataset(XX_valid, yy_valid)
        test_dataset = TensorDataset(XX_test, yy_test)
        
        train_dataloader = DataLoader(train_dataset, batch_size=batch_size, shuffle=False)
        valid_dataloader   = DataLoader(valid_dataset, batch_size=batch_size, shuffle=False)
        test_dataloader  = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)
        
        # 저장용 dictionary
        result_dict = {}
        
        # 고정변수 저장
        default_params = {
            'Input_Variables': Input_Variables,
            'Output_Variables': Output_Variables,
            'Input_Sequence': Input_Sequence,
            'Output_Sequence': Output_Sequence,
            'batch_size': batch_size,
            'scaling': scaling,
        }
        result_dict['default_params'] = default_params
        
        # 스케일러 저장
        if scaling == True:
            result_dict['ss_train'] = ss_train
            result_dict['mm_train'] = mm_train
            
        # loss function
        class MSLELoss(torch.nn.Module):
            def __init__(self, epsilon=1e-5):
                super(MSLELoss, self).__init__()
                self.epsilon = epsilon
        
            def forward(self, y_hat, y):
                return torch.mean((torch.log(1 + y + self.epsilon) - torch.log(1 + y_hat + self.epsilon))**2)
                
        
        # 하이퍼파라미터 튜닝
        
        def objective(trial):
            # 변수 정의
            channels = trial.suggest_categorical('channels', [1, 2, 3, 4, 5, 6])
            Kernel_Size = trial.suggest_categorical('Kernel_Size', [2, 3, 4, 5, 6, 7, 8, 9, 10])
            Dropout = trial.suggest_categorical('Dropout', [0.0, 0.1, 0.2, 0.3, 0.4, 0.5])
            learning_rate = trial.suggest_float('learning_rate', 1e-5, 1e-1, log=True)
            
            Num_Channels = []
            for i in range(channels):
                channel = trial.suggest_categorical(f'channel{i}', [16, 32, 64])
                Num_Channels.append(channel)
            
            print(f"trial.params: {trial.params}")
            
            # 모델 정의
            model = TCN(
                input_size=Input_Sequence, 
                output_size=Output_Sequence, 
                num_channels=Num_Channels, 
                kernel_size=Kernel_Size, 
                dropout=Dropout,
            )
            model = model.to(device)
            optimizer = optim.Adam(model.parameters(), lr=learning_rate)
            scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.95, patience=print_epochs2, verbose=False, threshold=0.0001, threshold_mode='rel', cooldown=0, min_lr=0, eps=1e-08)
            criterion = nn.MSELoss()
            # criterion = MSLELoss()     
            # criterion = torch.nn.SmoothL1Loss()
            # criterion = torch.nn.L1Loss()  
            
            # 학습
            best_validation_loss = float('INF')
            
            for epoch in range(EPOCHS):
                model.train()
                for train_inputs, train_targets in train_dataloader:
                    optimizer.zero_grad()
                    train_outputs = model(train_inputs)
                    loss = criterion(train_outputs, train_targets)
                    loss.backward()
                    optimizer.step()
        
                validation_loss = 0.0
                model.eval()
                with torch.no_grad():
                    for valid_inputs, valid_targets in valid_dataloader:
                        valid_outputs = model(valid_inputs)
                        valid_loss = criterion(valid_outputs, valid_targets)
                        validation_loss += valid_loss.item()
                
                validation_loss /= len(valid_dataloader)
                
                trial.report(validation_loss, epoch)
                scheduler.step(validation_loss)
                
                if epoch % print_epochs == 0:
                    print('| Epoch [{}/{}  |  {:.1%}  |  Loss: {:.4f}  |  Val Loss: {:.4f}  |  lr: {:.6f} '.format(epoch, EPOCHS, epoch/EPOCHS, loss.item(), validation_loss, optimizer.param_groups[0]['lr']))
                
                if validation_loss < best_validation_loss:
                    best_validation_loss = validation_loss
                    torch.save(model.state_dict(), result_f+'tcn_model.pth')
                
                if trial.should_prune():
                    raise optuna.exceptions.TrialPruned()
            
            return validation_loss
        
        def save_model(study, trial):
            if study.best_trial.number == trial.number:
                # Load the best model
                Num_Channels = []
                for i in range(trial.params['channels']):
                    Num_Channels.append(trial.params[f'channel{i}'])
                Kernel_Size = trial.params['Kernel_Size']
                Dropout = trial.params['Dropout']
                model = TCN(
                    input_size=Input_Sequence, 
                    output_size=Output_Sequence, 
                    num_channels=Num_Channels, 
                    kernel_size=Kernel_Size, 
                    dropout=Dropout, 
                )
                model = model.to(device)
                model.load_state_dict(torch.load(result_f+'tcn_model.pth'))
                model.eval()
                
                # Save the best model's parameters
                torch.save(model.state_dict(), result_f+'tcn_model_final.pth') 
                result_dict['state_dict'] = model.state_dict() 
        
        study = optuna.create_study(direction='minimize')#, sampler=optuna.samplers.RandomSampler(seed=42))
        study.optimize(objective, n_trials=TRIALS, callbacks=[save_model])
        print(f"Optimized parameters: {study.best_params}")
        
        # study 객체에서 best_params 추출
        best_params = study.best_params
        result_dict['best_params'] = best_params
        
        # 추출한 best_params를 DataFrame으로 변환
        best_df = pd.DataFrame.from_dict(best_params, orient='index', columns=['value'])
        
        # csv 파일로 저장
        best_df.to_csv(result_f+'tcn_best_params.csv', index=True)  
        
        with open(result_f+'tcn_result_dict.pkl', 'wb') as f:
            pickle.dump(result_dict, f)
            
        
        ############################################################################################################################    
        ######################################----------------Test---------------------------##################################   
        ############################################################################################################################
        best_params = result_dict['best_params']
        state_dict = result_dict['state_dict']
        default_params = result_dict['default_params']
        
        Input_Variables = default_params['Input_Variables']
        Output_Variables = default_params['Output_Variables']
        Input_Sequence = default_params['Input_Sequence']
        Output_Sequence = default_params['Output_Sequence']
        batch_size = default_params['batch_size']
        scaling = default_params['scaling']
        
        Num_Channels = []
        for i in range(best_params['channels']):
            Num_Channels.append(best_params[f'channel{i}'])
        Kernel_Size = best_params['Kernel_Size']
        Dropout = best_params['Dropout']
        
        model = TCN(
            input_size=Input_Sequence, 
            output_size=Output_Sequence, 
            num_channels=Num_Channels, 
            kernel_size=Kernel_Size, 
            dropout=Dropout, 
        )
        model = model.to(device)
        model.load_state_dict(state_dict)
        model.eval()
        
        y_true = pd.DataFrame()
        y_pred = pd.DataFrame()
        out_columns = ['%s(t+%d)'%(x,y) for x in Output_Variables for y in range(1, Output_Sequence + 1)]
        
        with torch.no_grad():
            for test_inputs, test_targets in test_dataloader:
                test_outputs = model(test_inputs)
                test_out = pd.DataFrame(test_outputs.cpu().numpy(),columns=out_columns)
                test_in = pd.DataFrame(test_targets.cpu().numpy(),columns=out_columns)
                y_true = pd.concat([y_true,test_in],ignore_index=True)
                y_pred = pd.concat([y_pred,test_out],ignore_index=True)
        
        if scaling == True:
            y_true = mm_train.inverse_transform(y_true)
            y_pred = mm_train.inverse_transform(y_pred)
        else:
            y_true = y_true.to_numpy()
            y_pred = y_pred.to_numpy()
        
        df_y_true = pd.DataFrame(y_true)
        df_y_pred = pd.DataFrame(y_pred)
        
        df_y_true.to_csv(result_f+'tcn_true.csv', index=True)
        df_y_pred.to_csv(result_f+'tcn_pred.csv', index=True)
        
        for i in range(Output_Sequence):
            true = y_true[:, i]
            pred = y_pred[:, i]
            
            V_R2 = np.round(r2_score(true, pred),6)
            V_MAE = np.round(mean_absolute_error(true, pred),6)
            V_RMSE = np.round(np.sqrt(mean_squared_error(true, pred)),6)
            
            print(f"prediction for {out_columns[i]}")
            print("R2:", V_R2, "MAE:", V_MAE, "RMSE:", V_RMSE)
            print()
            
            plt.figure(figsize=(15,6))
            plt.plot(pred, label='Predictions')
            plt.plot(true, label='Ground Truth')
            plt.title(f'{ite_num_out}ite_{out_columns[i]}')
            plt.legend()
            plt.show()